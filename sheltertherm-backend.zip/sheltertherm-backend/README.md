# ShelterTherm Backend

Node.js + Express + MongoDB backend prototype for the ShelterTherm / Himalayan Passive Shelter frontend.

## 1. Install

```bash
npm install
```

## 2. Environment

Copy `.env.example` to `.env` and set:

```env
PORT=5000
MONGODB_URI=mongodb://127.0.0.1:27017/sheltertherm
```

For MongoDB Atlas, replace `MONGODB_URI` with your Atlas connection string.

## 3. Start

```bash
npm start
```

Development:

```bash
npm run dev
```

## Main endpoints

- `GET /api/health`
- `GET /api/projects`
- `POST /api/projects`
- `GET /api/projects/:id`
- `PUT /api/projects/:id`
- `DELETE /api/projects/:id`
- `GET /api/materials`
- `POST /api/materials`
- `GET /api/climate/project/:projectId`
- `POST /api/climate`
- `POST /api/simulations/run`
- `GET /api/simulations/project/:projectId`

## Example simulation request

POST `/api/simulations/run`

```json
{
  "projectId": "PUT_MONGODB_PROJECT_ID_HERE",
  "outdoorTempC": -16.4,
  "targetIndoorC": 18,
  "solarWm2": 890,
  "solarGainKWhDay": 42.8,
  "lengthM": 6,
  "widthM": 4,
  "heightM": 2.8,
  "wallUValue": 0.35,
  "windowAreaM2": 6,
  "windowUValue": 1.8,
  "infiltrationACH": 0.35,
  "thermalMassKWh": 14.6
}
```

## Frontend example

```js
const response = await fetch("http://localhost:5000/api/simulations/run", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    outdoorTempC: -16.4,
    targetIndoorC: 18,
    solarWm2: 890,
    solarGainKWhDay: 42.8,
    lengthM: 6,
    widthM: 4,
    heightM: 2.8,
    wallUValue: 0.35,
    windowAreaM2: 6,
    windowUValue: 1.8,
    infiltrationACH: 0.35,
    thermalMassKWh: 14.6
  })
});

const data = await response.json();
console.log(data);
```

## Important

The thermal engine included here is a simplified prototype for a hackathon/demo. Its equations should be validated and replaced/calibrated against the actual scientific model, experimental data, or a validated simulation tool before real-world construction or safety decisions.
