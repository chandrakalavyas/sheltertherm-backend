const Climate = require("../models/Climate");

exports.list = async (req, res, next) => {
  try {
    const filter = req.params.projectId ? { projectId: req.params.projectId } : {};
    const data = await Climate.find(filter).sort({ timestamp: 1 }).limit(500);
    res.json({ success: true, data });
  } catch (err) {
    next(err);
  }
};

exports.create = async (req, res, next) => {
  try {
    const item = await Climate.create(req.body);
    res.status(201).json({ success: true, data: item });
  } catch (err) {
    next(err);
  }
};
