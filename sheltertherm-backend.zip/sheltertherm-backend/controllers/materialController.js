const Material = require("../models/Material");

exports.list = async (req, res, next) => {
  try {
    const data = await Material.find().sort({ name: 1 });
    res.json({ success: true, data });
  } catch (err) {
    next(err);
  }
};

exports.create = async (req, res, next) => {
  try {
    const material = await Material.create(req.body);
    res.status(201).json({ success: true, data: material });
  } catch (err) {
    next(err);
  }
};
