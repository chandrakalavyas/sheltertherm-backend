const Simulation = require("../models/Simulation");
const { calculateSimulation } = require("../services/thermalEngine");

exports.run = async (req, res, next) => {
  try {
    const result = calculateSimulation(req.body);

    const simulation = await Simulation.create({
      projectId: req.body.projectId,
      inputs: result.input,
      results: result.results,
      status: "completed"
    });

    res.status(201).json({
      success: true,
      simulationId: simulation._id,
      solver: simulation.solver,
      data: result
    });
  } catch (err) {
    next(err);
  }
};

exports.list = async (req, res, next) => {
  try {
    const filter = req.params.projectId ? { projectId: req.params.projectId } : {};
    const data = await Simulation.find(filter).sort({ createdAt: -1 }).limit(100);
    res.json({ success: true, data });
  } catch (err) {
    next(err);
  }
};
