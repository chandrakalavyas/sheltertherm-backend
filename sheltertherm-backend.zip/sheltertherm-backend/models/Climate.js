const mongoose = require("mongoose");

const ClimateSchema = new mongoose.Schema(
  {
    projectId: { type: mongoose.Schema.Types.ObjectId, ref: "Project", required: true },
    timestamp: { type: Date, default: Date.now },
    outdoorTempC: { type: Number, required: true },
    windSpeedMS: { type: Number, default: 0 },
    windDirection: { type: String, default: "WNW" },
    solarWm2: { type: Number, default: 0 },
    humidityPct: { type: Number, default: 50 }
  },
  { timestamps: true }
);

module.exports = mongoose.model("Climate", ClimateSchema);
