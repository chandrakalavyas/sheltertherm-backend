const mongoose = require("mongoose");

const MaterialSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, unique: true, trim: true },
    conductivityWmK: { type: Number, required: true },
    densityKgM3: { type: Number, required: true },
    specificHeatJkgK: { type: Number, required: true },
    thicknessM: { type: Number, default: 0.2 },
    description: String
  },
  { timestamps: true }
);

module.exports = mongoose.model("Material", MaterialSchema);
