const mongoose = require("mongoose");

const ProjectSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    location: { type: String, default: "Leh District, Ladakh" },
    altitudeM: { type: Number, default: 3524 },
    description: String,
    designVersion: { type: String, default: "v1.0" },
    activeSolver: {
      type: String,
      default: "1D Transient Thermal Network"
    },
    design: {
      lengthM: { type: Number, default: 6 },
      widthM: { type: Number, default: 4 },
      heightM: { type: Number, default: 2.8 },
      orientationDeg: { type: Number, default: 180 },
      wallUValue: { type: Number, default: 0.35 },
      windowAreaM2: { type: Number, default: 6 },
      windowUValue: { type: Number, default: 1.8 },
      infiltrationACH: { type: Number, default: 0.35 },
      thermalMassKWh: { type: Number, default: 14.6 }
    }
  },
  { timestamps: true }
);

module.exports = mongoose.model("Project", ProjectSchema);
