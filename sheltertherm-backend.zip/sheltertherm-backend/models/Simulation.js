const mongoose = require("mongoose");

const SimulationSchema = new mongoose.Schema(
  {
    projectId: { type: mongoose.Schema.Types.ObjectId, ref: "Project", required: true },
    inputs: mongoose.Schema.Types.Mixed,
    results: mongoose.Schema.Types.Mixed,
    solver: {
      type: String,
      default: "1D Transient Thermal Network"
    },
    status: {
      type: String,
      enum: ["completed", "failed"],
      default: "completed"
    }
  },
  { timestamps: true }
);

module.exports = mongoose.model("Simulation", SimulationSchema);
