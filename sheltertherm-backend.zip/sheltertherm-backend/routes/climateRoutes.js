const router = require("express").Router();
const controller = require("../controllers/climateController");

router.get("/project/:projectId", controller.list);
router.post("/", controller.create);

module.exports = router;
