const router = require("express").Router();
const controller = require("../controllers/simulationController");

router.post("/run", controller.run);
router.get("/project/:projectId", controller.list);

module.exports = router;
