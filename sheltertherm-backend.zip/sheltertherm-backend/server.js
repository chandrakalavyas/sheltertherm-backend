const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const connectDB = require("./config/db");

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json({ limit: "2mb" }));

app.get("/", (req, res) => {
  res.json({
    name: "ShelterTherm API",
    status: "running",
    version: "1.0.0"
  });
});

app.get("/api/health", (req, res) => {
  res.json({ ok: true, message: "ShelterTherm backend is healthy" });
});

app.use("/api/projects", require("./routes/projectRoutes"));
app.use("/api/materials", require("./routes/materialRoutes"));
app.use("/api/climate", require("./routes/climateRoutes"));
app.use("/api/simulations", require("./routes/simulationRoutes"));

app.use((err, req, res, next) => {
  console.error(err);
  res.status(err.status || 500).json({
    success: false,
    message: err.message || "Internal server error"
  });
});

async function start() {
  await connectDB();
  app.listen(PORT, () => {
    console.log(`ShelterTherm API running on http://localhost:${PORT}`);
  });
}

start();
