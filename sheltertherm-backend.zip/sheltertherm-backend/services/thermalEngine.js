/*
  ShelterTherm prototype thermal engine.

  IMPORTANT:
  These equations are simplified engineering/demo calculations for a
  hackathon prototype. They are NOT a validated building-energy model.
  Replace/calibrate them with your team's validated thermal model before
  using results for real construction or safety decisions.
*/

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function calculateSimulation(input = {}) {
  const outdoorTempC = Number(input.outdoorTempC ?? -16.4);
  const targetIndoorC = Number(input.targetIndoorC ?? 18);
  const solarWm2 = Number(input.solarWm2 ?? 890);
  const solarGainKWhDay = Number(input.solarGainKWhDay ?? 42.8);

  const lengthM = Number(input.lengthM ?? 6);
  const widthM = Number(input.widthM ?? 4);
  const heightM = Number(input.heightM ?? 2.8);
  const wallU = Number(input.wallUValue ?? 0.35);
  const windowArea = Number(input.windowAreaM2 ?? 6);
  const windowU = Number(input.windowUValue ?? 1.8);
  const infiltrationACH = Number(input.infiltrationACH ?? 0.35);
  const thermalMassKWh = Number(input.thermalMassKWh ?? 14.6);

  const floorArea = lengthM * widthM;
  const volume = floorArea * heightM;
  const wallArea = 2 * (lengthM + widthM) * heightM;
  const opaqueArea = Math.max(0, wallArea - windowArea);

  const deltaT = Math.max(0, targetIndoorC - outdoorTempC);

  // Approximate transmission loss (W -> kWh/day).
  const wallLossKWhDay = (opaqueArea * wallU * deltaT * 24) / 1000;
  const windowLossKWhDay = (windowArea * windowU * deltaT * 24) / 1000;

  // Simple infiltration approximation.
  const airHeatCapacityWhM3K = 0.33;
  const infiltrationLossKWhDay =
    (volume * infiltrationACH * deltaT * airHeatCapacityWhM3K * 24) / 1000;

  const totalHeatLossKWhDay =
    wallLossKWhDay + windowLossKWhDay + infiltrationLossKWhDay;

  const netDailyEnergyKWh =
    solarGainKWhDay - totalHeatLossKWhDay;

  const autonomyPct = clamp(
    (solarGainKWhDay / Math.max(totalHeatLossKWhDay, 0.001)) * 100,
    0,
    100
  );

  // Demonstration indoor-temperature estimate.
  const passiveOffset = clamp(
    (solarGainKWhDay / Math.max(totalHeatLossKWhDay, 1)) * 4,
    -10,
    12
  );
  const estimatedIndoorC = outdoorTempC + passiveOffset + 22;

  return {
    input: {
      outdoorTempC,
      targetIndoorC,
      solarWm2,
      solarGainKWhDay,
      lengthM,
      widthM,
      heightM,
      wallUValue: wallU,
      windowAreaM2: windowArea,
      windowUValue: windowU,
      infiltrationACH,
      thermalMassKWh
    },
    geometry: {
      floorAreaM2: Number(floorArea.toFixed(2)),
      volumeM3: Number(volume.toFixed(2)),
      opaqueWallAreaM2: Number(opaqueArea.toFixed(2))
    },
    results: {
      estimatedIndoorC: Number(estimatedIndoorC.toFixed(1)),
      outdoorTempC: Number(outdoorTempC.toFixed(1)),
      totalHeatLossKWhDay: Number(totalHeatLossKWhDay.toFixed(2)),
      transmissionLossKWhDay: Number((wallLossKWhDay + windowLossKWhDay).toFixed(2)),
      infiltrationLossKWhDay: Number(infiltrationLossKWhDay.toFixed(2)),
      solarGainKWhDay: Number(solarGainKWhDay.toFixed(2)),
      thermalStorageKWh: Number(thermalMassKWh.toFixed(2)),
      thermalAutonomyPct: Number(autonomyPct.toFixed(1)),
      netDailyEnergyKWh: Number(netDailyEnergyKWh.toFixed(2)),
      safeZone: estimatedIndoorC >= 16 && estimatedIndoorC <= 22
    }
  };
}

module.exports = { calculateSimulation };
